import csv
import string
from collections import defaultdict
from operator import itemgetter
from google.oauth2 import service_account
from googleapiclient.discovery import build

# Function to initialize Google Sheets service
def get_sheets_service():
    SCOPES = ['https://www.googleapis.com/auth/spreadsheets']
    SERVICE_ACCOUNT_FILE = 'our-highway-340916-11c0710a48d1.json'

    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=SCOPES)

    service = build('sheets', 'v4', credentials=credentials)
    return service.spreadsheets()

# Function to read CSV file content from Google Sheets
def read_csv_from_sheets(sheets_service, spreadsheet_id, range_name):
    result = sheets_service.values().get(spreadsheetId=spreadsheet_id, range=range_name).execute()
    values = result.get('values', [])
    if not values:
        return []
    else:
        return [dict(zip(values[0], row)) for row in values[1:]]

# Function to find top 5 destination country codes with highest Avg for male or female
def find_top_countries(origin_country, output_data):
    # Filter rows where the origin matches the specified country
    filtered_data = [row for row in output_data if row['Country'] == origin_country]
    # Sort the filtered data by 'Avg' in descending order
    sorted_data = sorted(filtered_data, key=lambda x: float(x['Avg']), reverse=True)
    # Extract the top 5 destination countries based on 'Avg'
    top_countries = [row['Destination Country'] for row in sorted_data[:3]]
    return top_countries

# Function to get the next available row number in the sheet
def get_next_available_row(sheet, spreadsheet_id):
    result = sheet.values().get(spreadsheetId=spreadsheet_id, range='Sheet1!A:A').execute()
    rows = result.get('values', [])
    next_row_number = len(rows) + 1
    return next_row_number
    
# Google Cloud Function
def migration_recommendation(request):
    # Extracting data from the request object
    request_data = request.get_data(as_text=True)
    
    # Remove all punctuations except commas
    punctuation_removed = ''.join([char if char == ',' or char not in string.punctuation else '' for char in request_data])
    
    # Splitting the request string
    request_list = punctuation_removed.split(",")
    
    # Assume the function is triggered with some data processing
    origin_country = request_list[0]
    sex = request_list[2]

    # ID of the spreadsheets
    output_spreadsheet_id = '1MlIbmxpShsNj43U6LyUt34PB5gtPlkWlCUHu_wPtJyk'
    country_location_mapping_spreadsheet_id = '1pACv72YU-ad0oFWABQAy6-eD_CeDblNvltROjrvWTYY'

    # Initialize Google Sheets service
    sheets_service = get_sheets_service()

    # Read CSV files from Google Sheets
    output_data = read_csv_from_sheets(sheets_service, output_spreadsheet_id, 'Sheet1')
    country_location_mapping_data = read_csv_from_sheets(sheets_service, country_location_mapping_spreadsheet_id, 'Sheet1')
    
    # Find top 5 destination country codes
    recommended_countries = find_top_countries(origin_country, output_data)

    # ID of the spreadsheet
    SPREADSHEET_ID = '1X8l8aOvoV-Q96_Z-MeDsfqKrzJLjSONvd_kTydDxjMw'

    # Initialize Google Sheets service
    sheet = get_sheets_service()

    # Get the next available row number
    next_row_number = get_next_available_row(sheet, SPREADSHEET_ID)

    # Prepare the data to write
    values = [
        [",".join(request_list), *recommended_countries]  # Include ID column and recommended countries
    ]
    body = {
        'values': values
    }
    
    # Write data
    result = sheet.values().append(
        spreadsheetId=SPREADSHEET_ID,
        range=f'Sheet1!A{next_row_number}',  # Append data to the next available row
        valueInputOption='RAW',
        body=body
    ).execute()

    return f"Updated {result.get('updates').get('updatedCells')} cells in Sheet."
